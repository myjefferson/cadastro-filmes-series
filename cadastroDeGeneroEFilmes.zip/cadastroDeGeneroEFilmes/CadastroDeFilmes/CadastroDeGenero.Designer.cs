﻿namespace CadastroDeFilmes
{
    partial class CadastroDeGenero
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastroDeGenero));
            this.button1 = new System.Windows.Forms.Button();
            this.txtGenero = new System.Windows.Forms.TextBox();
            this.btnCadFilmes = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkRed;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 12.75F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(57, 295);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(262, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "CADASTRAR GÊNERO";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnCadastroGenero);
            // 
            // txtGenero
            // 
            this.txtGenero.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtGenero.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtGenero.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F);
            this.txtGenero.ForeColor = System.Drawing.SystemColors.Window;
            this.txtGenero.Location = new System.Drawing.Point(67, 246);
            this.txtGenero.Name = "txtGenero";
            this.txtGenero.Size = new System.Drawing.Size(251, 22);
            this.txtGenero.TabIndex = 1;
            this.txtGenero.TextChanged += new System.EventHandler(this.TextBox1_TextChanged);
            // 
            // btnCadFilmes
            // 
            this.btnCadFilmes.BackColor = System.Drawing.Color.Transparent;
            this.btnCadFilmes.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCadFilmes.FlatAppearance.BorderSize = 0;
            this.btnCadFilmes.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.HotTrack;
            this.btnCadFilmes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCadFilmes.Font = new System.Drawing.Font("Arial", 12.75F, System.Drawing.FontStyle.Bold);
            this.btnCadFilmes.ForeColor = System.Drawing.SystemColors.Window;
            this.btnCadFilmes.Location = new System.Drawing.Point(58, 346);
            this.btnCadFilmes.Name = "btnCadFilmes";
            this.btnCadFilmes.Size = new System.Drawing.Size(262, 42);
            this.btnCadFilmes.TabIndex = 0;
            this.btnCadFilmes.Text = "CADASTRAR FILMES";
            this.btnCadFilmes.UseVisualStyleBackColor = false;
            this.btnCadFilmes.Click += new System.EventHandler(this.btnCadastrarFilmes);
            // 
            // CadastroDeGenero
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(378, 489);
            this.Controls.Add(this.txtGenero);
            this.Controls.Add(this.btnCadFilmes);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CadastroDeGenero";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro do Gênero do Filme";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CadastroDeGenero_FormClosing);
            this.Load += new System.EventHandler(this.CadastroDeGenero_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtGenero;
        private System.Windows.Forms.Button btnCadFilmes;
    }
}