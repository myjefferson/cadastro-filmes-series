﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CadastroDeFilmes
{
    public partial class CadastrarFilme : Form
    {
        public CadastrarFilme()
        {
            InitializeComponent();
        }
        public CadastrarFilme(ListaFilme filmes)
        {
            InitializeComponent();
            var lista = filmes;

            foreach (var item in lista)
            {
                cbxLista.Items.Add(item.Genero);
            }
        }


        private void CadastrarFilme_Load(object sender, EventArgs e)
        {

        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        { 

            try //tentar
            {
                FolderBrowserDialog salvar = new FolderBrowserDialog(); //mostra a janela de salvar 
                salvar.Description = "ESCOLHA UMA PASTA PARA SALVAR O ARQUIVO!";
                salvar.ShowNewFolderButton = true;
                salvar.ShowDialog();

                string escolha = salvar.SelectedPath + @"arquivo.txt";

                using (FileStream sw = File.Create(escolha))
                {
                    using (StreamWriter escreva = new StreamWriter(sw))
                    {
                        escreva.WriteLine("Nome do Filme: " + txtNomeFilme.Text);
                        escreva.WriteLine("Produtor: "+txtProdutor.Text);
                        escreva.WriteLine("Ano: "+txtAno.Text);
                        escreva.WriteLine("Gênero: "+cbxLista.Text);
                    }
                }
            }
            catch (Exception ex)  //catch = tradução : capturar/pegar (Exeto o ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}


