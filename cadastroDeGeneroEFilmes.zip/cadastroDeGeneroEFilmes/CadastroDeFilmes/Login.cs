﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

using WMPLib;


namespace CadastroDeFilmes
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();           
        }

        private void btnEntrar(object sender, EventArgs e)
        {
            if(txtUsuario.Text == "Luiz")
            {
                if(txtSenha.Text == "12345")
                {
                    MessageBox.Show("LOGADO COM SUCESSO!\nCLIQUE EM OK PARA CONTINUAR");
                    CadastroDeGenero generoArea = new CadastroDeGenero();
                    generoArea.Show();
                    this.Hide();                  
                }
                else
                {
                    MessageBox.Show("ERRO AO FAZER LOGIN,\nTENTE NOVAMENTE!");
                    txtUsuario.Clear();
                    txtSenha.Clear();
                }
            }
            else
            {
                MessageBox.Show("ERRO AO FAZER LOGIN,\nTENTE NOVAMENTE!");
                txtUsuario.Clear();
                txtSenha.Clear();
            }
        }

        private void btnLimpar(object sender, EventArgs e)
        {
            txtUsuario.Clear();
            txtSenha.Clear();
        }

        private void Login_Load(object sender, EventArgs e) //Carregar Login
        {
            WindowsMediaPlayer player = new WindowsMediaPlayer(); //Instância do WindowsMediaPlayer
            player.URL = "intro_song_netflix.mp3"; //localiza o local do som na pasta DEBUG
            player.controls.play(); // Inicia o Som / player. controles. iniciar();

            IntroNetflix.Visible = true; //Visibilidade = Verdadeira
            Timer tempo = new Timer(); //Instância do Timer
            tempo.Interval = 4800; //intervalo de contagem
            tempo.Tick += new EventHandler(tempoContage);
            tempo.Start(); //Reproduz a contagem
        }

        private void Panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tempoContage(object sender, EventArgs e) //sender = remetente
        {
            IntroNetflix.Visible = false; // Visibilidade da PictureBox falsa
            (sender as Timer).Stop(); //O object sender como Tempo. Para()
        }

    }
}
