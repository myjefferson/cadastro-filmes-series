﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CadastroDeFilmes
{
    public partial class CadastroDeGenero : Form
    {
        ListaFilme listaFilme = new ListaFilme();     
        public CadastroDeGenero()
        {
            InitializeComponent();
            
        }

        private void CadastroDeGenero_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastroGenero(object sender, EventArgs e)
        {
            Filme filme = new Filme();

            filme.Genero = txtGenero.Text;

            MessageBox.Show("GÊNERO CADASTRADO COM SUCESSO!");
            listaFilme.Add(filme);

            txtGenero.Clear();
            txtGenero.Focus();
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnCadastrarFilmes(object sender, EventArgs e)
        {
            CadastrarFilme cadastrarFilme = new CadastrarFilme(listaFilme);
            //É preciso levar as informações da classe listaFilme/ListaFilme para a classe CadastrarFilmes.cs
            cadastrarFilme.Show();
        }

        private void CadastroDeGenero_Load(object sender, EventArgs e)
        {

        }

        private void CbxLista_Click(object sender, EventArgs e)
        {

        }
    }
}
