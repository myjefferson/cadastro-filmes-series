﻿namespace CadastroDeFilmes
{
    partial class CadastrarFilme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarFilme));
            this.button1 = new System.Windows.Forms.Button();
            this.txtNomeFilme = new System.Windows.Forms.TextBox();
            this.txtAno = new System.Windows.Forms.TextBox();
            this.txtProdutor = new System.Windows.Forms.TextBox();
            this.cbxLista = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.FlatAppearance.BorderSize = 0;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.HotTrack;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Arial", 12.75F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Transparent;
            this.button1.Location = new System.Drawing.Point(155, 410);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(201, 43);
            this.button1.TabIndex = 0;
            this.button1.Text = "Salvar Cadastro";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtNomeFilme
            // 
            this.txtNomeFilme.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtNomeFilme.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtNomeFilme.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtNomeFilme.ForeColor = System.Drawing.Color.White;
            this.txtNomeFilme.Location = new System.Drawing.Point(63, 183);
            this.txtNomeFilme.Name = "txtNomeFilme";
            this.txtNomeFilme.Size = new System.Drawing.Size(253, 20);
            this.txtNomeFilme.TabIndex = 0;
            // 
            // txtAno
            // 
            this.txtAno.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtAno.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtAno.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtAno.ForeColor = System.Drawing.Color.White;
            this.txtAno.Location = new System.Drawing.Point(63, 305);
            this.txtAno.Name = "txtAno";
            this.txtAno.Size = new System.Drawing.Size(253, 20);
            this.txtAno.TabIndex = 2;
            // 
            // txtProdutor
            // 
            this.txtProdutor.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.txtProdutor.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtProdutor.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.txtProdutor.ForeColor = System.Drawing.Color.White;
            this.txtProdutor.Location = new System.Drawing.Point(63, 244);
            this.txtProdutor.Name = "txtProdutor";
            this.txtProdutor.Size = new System.Drawing.Size(253, 20);
            this.txtProdutor.TabIndex = 3;
            this.txtProdutor.TextChanged += new System.EventHandler(this.TextBox4_TextChanged);
            // 
            // cbxLista
            // 
            this.cbxLista.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.cbxLista.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.cbxLista.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.cbxLista.ForeColor = System.Drawing.Color.White;
            this.cbxLista.FormattingEnabled = true;
            this.cbxLista.Items.AddRange(new object[] {
            "Drama",
            "Ficção-Cientifica",
            "Romance",
            "Evangêlicos",
            "Terror",
            "Horror",
            "Detetive",
            "Aventura",
            "Fantasia",
            "Suspense"});
            this.cbxLista.Location = new System.Drawing.Point(55, 363);
            this.cbxLista.Name = "cbxLista";
            this.cbxLista.Size = new System.Drawing.Size(268, 28);
            this.cbxLista.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Transparent;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkRed;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Arial", 12.75F, System.Drawing.FontStyle.Bold);
            this.button2.ForeColor = System.Drawing.SystemColors.Window;
            this.button2.Location = new System.Drawing.Point(22, 411);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 42);
            this.button2.TabIndex = 4;
            this.button2.Text = "Voltar";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // CadastrarFilme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(378, 489);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.cbxLista);
            this.Controls.Add(this.txtProdutor);
            this.Controls.Add(this.txtAno);
            this.Controls.Add(this.txtNomeFilme);
            this.Controls.Add(this.button1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "CadastrarFilme";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Filmes";
            this.Load += new System.EventHandler(this.CadastrarFilme_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtNomeFilme;
        private System.Windows.Forms.TextBox txtAno;
        private System.Windows.Forms.TextBox txtProdutor;
        private System.Windows.Forms.ComboBox cbxLista;
        private System.Windows.Forms.Button button2;
    }
}